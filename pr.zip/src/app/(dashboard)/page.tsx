import React from 'react'
import Projectcard from '@/components/Cards/Projectcard'
const DashboardPage = () => {

  const cards = [
    {
      id: 1,
      image: "/Auth/login.png",
      category: "Civil Engineering",
      title: "Eco-Smart Bridge Infrastructure",
      description:
        "Next-gen structural design with integrated IoT sensors for real-time monitoring.",
      rating: 4.9,
      author: "Alex Rivera",
      authorAvatar: "/Topbar/ProfileImage.png",
      price: 120,
      bookmarked: true,
    },
    {
      id: 2,
      image: "/Auth/login.png",
      category: "Civil Engineering",
      title: "Eco-Smart Bridge Infrastructure",
      description:
        "Next-gen structural design with integrated IoT sensors for real-time monitoring.",
      rating: 4.9,
      author: "Alex Rivera",
      authorAvatar: "/Topbar/ProfileImage.png",
      price: 120,
      bookmarked: true,
    },
    {
      id: 3,
      image: "/Auth/login.png",
      category: "Civil Engineering",
      title: "Eco-Smart Bridge Infrastructure",
      description:
        "Next-gen structural design with integrated IoT sensors for real-time monitoring.",
      rating: 4.9,
      author: "Alex Rivera",
      authorAvatar: "/Topbar/ProfileImage.png",
      price: 120,
      bookmarked: true,
    },
    {
      id: 4,
      image: "/Auth/login.png",
      category: "Civil Engineering",
      title: "Eco-Smart Bridge Infrastructure",
      description:
        "Next-gen structural design with integrated IoT sensors for real-time monitoring.",
      rating: 4.9,
      author: "Alex Rivera",
      authorAvatar: "/Topbar/ProfileImage.png",
      price: 120,
      bookmarked: true,
    },
    {
      id: 5,
      image: "/Auth/login.png",
      category: "Civil Engineering",
      title: "Eco-Smart Bridge Infrastructure",
      description:
        "Next-gen structural design with integrated IoT sensors for real-time monitoring.",
      rating: 4.9,
      author: "Alex Rivera",
      authorAvatar: "/Topbar/ProfileImage.png",
      price: 120,
      bookmarked: true,
    },
    {
      id: 6,
      image: "/Auth/login.png",
      category: "Civil Engineering",
      title: "Eco-Smart Bridge Infrastructure",
      description:
        "Next-gen structural design with integrated IoT sensors for real-time monitoring.",
      rating: 4.9,
      author: "Alex Rivera",
      authorAvatar: "/Topbar/ProfileImage.png",
      price: 120,
      bookmarked: true,
    },
    {
      id: 7,
      image: "/Auth/login.png",
      category: "Civil Engineering",
      title: "Eco-Smart Bridge Infrastructure",
      description:
        "Next-gen structural design with integrated IoT sensors for real-time monitoring.",
      rating: 4.9,
      author: "Alex Rivera",
      authorAvatar: "/Topbar/ProfileImage.png",
      price: 120,
      bookmarked: true,
    },
    {
      id: 8,
      image: "/Auth/login.png",
      category: "Civil Engineering",
      title: "Eco-Smart Bridge Infrastructure",
      description:
        "Next-gen structural design with integrated IoT sensors for real-time monitoring.",
      rating: 4.9,
      author: "Alex Rivera",
      authorAvatar: "/Topbar/ProfileImage.png",
      price: 120,
      bookmarked: true,
    },
  ];

  return (
    // <div className="w-full overflow-hidden">
    //   <div className="overflow-x-auto md:overflow-visible">
    //     <div className="flex gap-6  md:grid md:grid-cols-3 xl:grid-cols-4">
    //       {cards.map((card) => (
    //         <div
    //           key={card.id}
    //           className="w-[320px] shrink-0 md:w-auto"
    //         >
    //           <Projectcard {...card} />
    //         </div>
    //       ))}
    //     </div>
    //   </div>
    // </div>
    <div>
      {/* <div className="md:hidden">
        <div className="overflow-x-auto">
          <div className="flex gap-6">
            {cards.map((card) => (
              <div key={card.id} className="w-[320px] shrink-0">
                <Projectcard {...card} />
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="hidden md:grid md:grid-cols-3 xl:grid-cols-4 gap-6">
        {cards.map((card) => (
          <Projectcard key={card.id} {...card} />
        ))}
      </div> */}
      <div className="w-full max-w-full overflow-x-auto">
        <div className="inline-flex gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div
              key={i}
              className="w-[320px] h-[200px] flex-none bg-red-500"
            />
          ))}
        </div>
      </div>
    </div>
  )
}

export default DashboardPage